
cc.Class({
    extends: cc.Component,

    properties: {
        _score:0,
        scoreGame: cc.RichText,
        loseLayout: cc.Layout,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        
    },

    start () {
        this.updateScore();
    },
    updateScore() {
        let actions = [
                        cc.delayTime(0.03),
                        cc.callFunc(() => { this.scoreGame.string = `<color=#0fffff>${this._score++}</color>`
                    })]
        this.scoreGame.node.runAction(cc.repeat(cc.sequence(actions), 101))
    },
    countDownScore(){
        this.scoreGame.node.runAction(cc.repeatForever(
            cc.sequence(
                    cc.callFunc(this.checkScore()),
                    cc.delayTime(2),
                    cc.callFunc(()=>{ this.scoreGame.string = `<color=#0fffff>${this._score--}</color>`})
                )
            )
        );
    },
    checkScore(){
        if(this._score <= 0){
            this.node.stopAllActions();
            return this.loseGame();
        }
    },
    loseGame(){
        this.loseLayout.node.active = true;
    },
    update (dt) {
        // if(this._score == 100){
        //     // cc.log(true);
        //     // cc.log(this._score);
        //     return this.countDownScore();
        // }
    },
});

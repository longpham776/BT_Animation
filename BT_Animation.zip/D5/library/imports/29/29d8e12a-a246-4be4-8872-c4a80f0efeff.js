"use strict";
cc._RF.push(module, '29d8eEqokZL5IhyxKgPDv7/', 'Score');
// Script/Score.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        _score: 0,
        scoreGame: cc.RichText,
        loseLayout: cc.Layout
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {},
    start: function start() {
        this.updateScore();
    },
    updateScore: function updateScore() {
        var _this = this;

        var actions = [cc.delayTime(0.03), cc.callFunc(function () {
            _this.scoreGame.string = "<color=#0fffff>" + _this._score++ + "</color>";
        })];
        this.scoreGame.node.runAction(cc.repeat(cc.sequence(actions), 101));
    },
    countDownScore: function countDownScore() {
        var _this2 = this;

        this.scoreGame.node.runAction(cc.repeatForever(cc.sequence(cc.callFunc(this.checkScore()), cc.delayTime(2), cc.callFunc(function () {
            _this2.scoreGame.string = "<color=#0fffff>" + _this2._score-- + "</color>";
        }))));
    },
    checkScore: function checkScore() {
        if (this._score <= 0) {
            this.node.stopAllActions();
            return this.loseGame();
        }
    },
    loseGame: function loseGame() {
        this.loseLayout.node.active = true;
    },
    update: function update(dt) {
        // if(this._score == 100){
        //     // cc.log(true);
        //     // cc.log(this._score);
        //     return this.countDownScore();
        // }
    }
});

cc._RF.pop();
"use strict";
cc._RF.push(module, '6e1e63+uYdNbavegsW2rKOZ', 'Collider');
// Script/Collider.js

'use strict';

var Emitter = require('mEmitter');
cc.Class({
    extends: cc.Component,

    properties: {
        winLayout: cc.Layout,
        loseLayout: cc.Layout,
        _flag: false
    },

    // LIFE-CYCLE CALLBACKS:
    onCollisionEnter: function onCollisionEnter(other, self) {
        cc.log('on collision enter');
        cc.log(self);
        cc.log(other);
        switch (self.node.name) {
            case "SpineBoy":
                if (other.node.name == "windoor") {
                    this.winLayout.node.active = true;
                    self.node.getComponent(sp.Skeleton).setAnimation(0, 'idle', false);
                    self.node.stopAllActions();
                } else if (other.node.name == "StartLayout") {
                    self.node.getComponent(sp.Skeleton).setAnimation(0, 'idle', false);
                    self.node.runAction(cc.moveBy(0, 5, 0));
                } else if (other.node.name == "EndLayout") {
                    self.node.getComponent(sp.Skeleton).setAnimation(0, 'idle', false);
                    self.node.runAction(cc.moveBy(0, -5, 0));
                } else if (other.node.name == "Spike" || other.node.name == "Rabbit") {
                    if (!this._flag) {
                        this._flag = true;
                        self.node.getComponent(sp.Skeleton).setAnimation(0, 'death', false);
                        this.loseLayout.node.active = true;
                    }
                    self.node.stopAllActions();
                    other.node.stopAllActions();
                    cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN);
                    cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP);
                }
                break;
            case "Bullet":
                if (other.node.name == "Rabbit") {
                    cc.log(self.node.getChildren(cc.ParticleSystem)[0].active);
                    self.node.getChildren(cc.ParticleSystem)[0].active = true;
                    other.node.runAction(cc.blink(0.5, 3));
                    // cc.log(other.node._children[0]._components[1].barSprite.node.color.b);
                    other.node._children[0]._components[1].progress -= 0.1;
                    if (other.node._children[0]._components[1].progress <= 0) other.node.destroy();
                }
                break;
            case "Rabbit":
                if (other.node.name == "SpineBoy") {
                    self.node.runAction(cc.speed(cc.moveBy(1, -150, 0), 3));
                }
                break;
        }
    },
    onCollisionStay: function onCollisionStay(other, self) {
        // cc.log('on collision stay');
        switch (self.node.name) {
            case "SpineBoy":
                if (other.node.name == "StartLayout") {
                    self.node.getComponent(sp.Skeleton).setAnimation(0, 'idle', false);
                    self.node.runAction(cc.moveBy(0, 5, 0));
                } else if (other.node.name == "EndLayout") {
                    self.node.getComponent(sp.Skeleton).setAnimation(0, 'idle', false);
                    self.node.runAction(cc.moveBy(0, -5, 0));
                } else if (other.node.name == "windoor") {
                    this.winLayout.node.active = true;
                    self.node.getComponent(sp.Skeleton).setAnimation(0, 'idle', false);
                    self.node.stopAllActions();
                }
                break;
        }
    },
    onCollisionExit: function onCollisionExit(other, self) {
        // cc.log('on collision exit');
    },
    onLoad: function onLoad() {
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
        // manager.enabledDebugDraw = true;
        // manager.enabledDrawBoundingBox =true;
    },
    start: function start() {},
    update: function update(dt) {}
});

cc._RF.pop();
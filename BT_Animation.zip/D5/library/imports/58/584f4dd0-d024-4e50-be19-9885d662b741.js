"use strict";
cc._RF.push(module, '584f43Q0CROUL4ZmIXWYrdB', 'ScaleY');
// Script/ScaleY.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.node.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(0.5, 0.4, 0.35), cc.scaleTo(0.5, 0.4, 0.4))));
    }
}
// update (dt) {},
);

cc._RF.pop();
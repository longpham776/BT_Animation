"use strict";
cc._RF.push(module, '584f43Q0CROUL4ZmIXWYrdB', 'ScaleY');
// Script/ScaleY.js

"use strict";

var Emitter = require('mEmitter');
cc.Class({
    extends: cc.Component,

    properties: {
        Hp: cc.ProgressBar,
        _decreaseHp: null
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this._decreaseHp = this.decreaseHp.bind(this);

        Emitter.instance = new Emitter();
        Emitter.instance.registerEvent("hit", this._decreaseHp);
    },
    decreaseHp: function decreaseHp(value) {
        cc.log(value);
        this.Hp.progress -= 0.1;
    },
    start: function start() {
        this.Hp.progress = 1;
        this.node.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(0.5, 0.4, 0.38), cc.scaleTo(0.5, 0.4, 0.4))));
        this.node.runAction(cc.repeatForever(cc.sequence(cc.moveBy(3, -150, 0), cc.delayTime(3), cc.moveBy(3, 150, 0), cc.delayTime(3))));
    },
    update: function update(dt) {
        cc.speed();
        if (Math.floor(this.node.x) <= 21) {
            this.node.runAction(cc.sequence(cc.delayTime(3), cc.flipX(true)));
        } else if (Math.floor(this.node.x) >= 171) {
            this.node.runAction(cc.sequence(cc.delayTime(3), cc.flipX(false)));
        }
    }
});

cc._RF.pop();
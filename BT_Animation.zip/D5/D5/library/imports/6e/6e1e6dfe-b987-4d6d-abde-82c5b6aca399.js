"use strict";
cc._RF.push(module, '6e1e63+uYdNbavegsW2rKOZ', 'Collider');
// Script/Collider.js

'use strict';

var Emitter = require('mEmitter');
cc.Class({
    extends: cc.Component,

    properties: {
        winLayout: cc.Layout
    },

    // LIFE-CYCLE CALLBACKS:
    onCollisionEnter: function onCollisionEnter(other, self) {
        cc.log('on collision enter');
        cc.log(self);
        cc.log(other);
        switch (self.node.name) {
            case "SpineBoy":
                self.node.getComponent(sp.Skeleton).setAnimation(0, 'death', false);
                if (other.node.name == "windoor") {
                    this.winLayout.node.active = true;
                }
                break;
            case "Bullet":
                if (other.node.name == "Rabbit") {
                    self.node.destroy();
                    other.node.runAction(cc.blink(0.5, 3));
                    cc.log(other.node._children[0]._components[1].barSprite.node.color.b);
                    other.node._children[0]._components[1].progress -= 0.1;
                    if (other.node._children[0]._components[1].progress <= 0) other.node.destroy();
                    Emitter.instance.emit('hit', true);
                }
                break;
        }
    },
    onCollisionStay: function onCollisionStay(other, self) {
        cc.log('on collision stay');
    },
    onCollisionExit: function onCollisionExit(other, self) {
        cc.log('on collision exit');
    },
    onLoad: function onLoad() {
        var manager = cc.director.getCollisionManager();
        manager.enabled = true;
        manager.enabledDebugDraw = true;
        manager.enabledDrawBoundingBox = true;
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
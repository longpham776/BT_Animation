const Emitter = require('mEmitter');
cc.Class({
    extends: cc.Component,

    properties: {
        Hp: cc.ProgressBar,
        _decreaseHp: null,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this._decreaseHp=this.decreaseHp.bind(this);

        Emitter.instance = new Emitter();
        Emitter.instance.registerEvent("hit", this._decreaseHp);
    },
    decreaseHp(value){
        cc.log(value);
        this.Hp.progress -= 0.1;
    },
    start () {
        this.Hp.progress = 1;
        this.node.runAction(cc.repeatForever(cc.sequence(cc.scaleTo(0.5,0.4,0.38),cc.scaleTo(0.5,0.4,0.4))));
    },
    // update (dt) {},
});

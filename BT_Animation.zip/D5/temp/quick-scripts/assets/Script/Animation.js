(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Animation.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '9b28ffIUXRINaX4xYH+BqEr', 'Animation', __filename);
// Script/Animation.js

"use strict";

var Emitter = require('mEmitter');
cc.Class({
    extends: cc.Component,

    properties: {
        Skeleton: sp.Skeleton,
        Bullet: cc.Prefab,
        _jump: null,
        _slide: null,
        _moveLeft: null,
        _moveRight: null,
        _shoot: null,
        _flag: false
    },

    // LIFE-CYCLE CALLBACKS:
    onLoad: function onLoad() {
        this._jump = this.jump.bind(this);
        this._slide = this.slide.bind(this);
        this._moveRight = this.moveRight.bind(this);
        this._moveLeft = this.moveLeft.bind(this);
        this._shoot = this.shoot.bind(this);

        Emitter.instance = new Emitter();
        Emitter.instance.registerEvent("keyup_down", this._jump);

        Emitter.instance.registerEvent("keydown_up", this._slide);

        Emitter.instance.registerEvent("keyright_down", this._moveRight);
        Emitter.instance.registerEvent("keyright_up", this._moveRight);

        Emitter.instance.registerEvent("keyleft_down", this._moveLeft);
        Emitter.instance.registerEvent("keyleft_up", this._moveLeft);

        Emitter.instance.registerEvent("keyspace_down", this._shoot);
        // Emitter.instance.registerEvent("keyspace_up", this._shoot);
    },
    shoot: function shoot(value) {
        cc.log(value);
        if (!this._flag) {
            // this._flag = true;
            var bullet = cc.instantiate(this.Bullet);
            bullet.parent = this.Skeleton.node;
            bullet.active = true;
            bullet.runAction(cc.sequence(cc.moveBy(1, 3000, 0), cc.callFunc(this.removeBullet, this)));
            this.Skeleton.setAnimation(0, "idle-shoot", false);
            this.Skeleton.addAnimation(0, "idle", true);
        }
    },
    removeBullet: function removeBullet() {
        for (var i = 0; i < this.node._children.length; i++) {
            this.node._children[i].destroy();
        }
    },
    jump: function jump(value) {
        var _this = this;

        cc.log(value);
        if (!this._flag) {

            var jumpUp = cc.moveBy(0.4, cc.v2(0, 50));
            var jumpDown = cc.moveBy(1, cc.v2(0, -50));
            var jump = cc.sequence(jumpUp, cc.delayTime(0.1), jumpDown);
            this.node.runAction(jump);
            this._flag = true;
            this.Skeleton.setAnimation(0, "jump", false);
            this.Skeleton.addAnimation(0, "idle-turn", false);
            this.Skeleton.addAnimation(0, "idle", true);
            this.Skeleton.setEventListener(function (entry, event) {
                if (entry.animationEnd != 0) {
                    _this._flag = false;
                }
            });
        }
    },
    slide: function slide(value) {
        var _this2 = this;

        cc.log(value);
        if (!this._flag) {
            this._flag = true;
            this.Skeleton.setAnimation(0, "hoverboard", true);
            this.Skeleton.setEventListener(function (entry, event) {
                if (entry.animationEnd != 0) _this2._flag = false;
            });
        }
    },
    moveLeft: function moveLeft(value) {
        cc.log(value);
        var move = cc.sequence(cc.moveBy(5, -1000, 0), cc.moveBy(4, -3000, 0));
        if (!this._flag && value) {
            this._flag = true;
            this.node.runAction(cc.flipX(true));
            this.node.runAction(move);
            move.setTag(0);
            this.Skeleton.setAnimation(0, "walk", false);
            this.Skeleton.addAnimation(0, "run", true);
        } else if (!this._flag || !value) {
            this._flag = false;
            this.node.stopActionByTag(0);
            this.Skeleton.setAnimation(0, "idle", true);
        }
    },
    moveRight: function moveRight(value) {
        cc.log(value);
        var move = cc.sequence(cc.moveBy(5, 1000, 0), cc.moveBy(4, 3000, 0));
        if (!this._flag && value) {
            this._flag = true;
            this.node.runAction(cc.flipX(false));
            this.node.runAction(move);
            move.setTag(0);
            this.Skeleton.setAnimation(0, "walk", false);
            this.Skeleton.addAnimation(0, "run", true);
        } else if (!this._flag || !value) {
            this._flag = false;
            this.node.stopActionByTag(0);
            this.Skeleton.setAnimation(0, "idle", true);
        }
    },
    start: function start() {
        this.Skeleton.setAnimation(0, "portal", false);
        this.Skeleton.addAnimation(0, "idle", true);
        // this.Skeleton.setCompleteListener(this.Skeleton.setToSetupPose());
        // this.Skeleton.setEventListener((entry,event)=>{cc.log(entry)});
        // this.Skeleton.setToSetupPose();
    },
    update: function update(dt) {
        this.node.getComponent(cc.BoxCollider).offset = cc.v2(this.Skeleton.findBone("torso3").worldX, this.Skeleton.findBone("torso3").worldY);
        // cc.log(this.Skeleton.findBone("torso3"));
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Animation.js.map
        